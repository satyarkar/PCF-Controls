var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./AutoPopulateTextColumn/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./AutoPopulateTextColumn/index.ts":
/*!*****************************************!*\
  !*** ./AutoPopulateTextColumn/index.ts ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.AutoPopulateTextColumn = void 0;\n\nvar AutoPopulateTextColumn =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function AutoPopulateTextColumn() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  AutoPopulateTextColumn.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this._context = context;\n    this._container = document.createElement(\"div\");\n    this._notifyOutputChanged = notifyOutputChanged; // creating HTML elements for the auto populate text column\n\n    this.inputElement = document.createElement(\"input\");\n    this.inputElement.setAttribute(\"class\", \"boundText\");\n    this.inputElement.setAttribute(\"placeholder\", \"---\"); // retrieving the latest value from the component.\n\n    this._value = context.parameters.boundTextProperty.raw ? context.parameters.boundTextProperty.raw : \"\";\n    this.inputElement.value = this._value;\n    this.inputElement.addEventListener(\"blur\", this.onBlur.bind(this));\n    this._regardingValue = context.parameters.regardingValue.raw ? context.parameters.regardingValue.raw : null;\n    this._configValue = context.parameters.configValue.raw ? context.parameters.configValue.raw : \"\";\n    this.autoPopulate(this._regardingValue); // appending the HTML elements to the component's HTML container element.\n\n    this._container.appendChild(this.inputElement);\n\n    container.appendChild(this._container);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  AutoPopulateTextColumn.prototype.updateView = function (context) {\n    var newRegardingValue = context.parameters.regardingValue.raw ? context.parameters.regardingValue.raw : null;\n    this.autoPopulate(newRegardingValue);\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  AutoPopulateTextColumn.prototype.getOutputs = function () {\n    return {\n      boundTextProperty: this._value\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  AutoPopulateTextColumn.prototype.destroy = function () {// add code to cleanup control if necessary\n  };\n  /**\r\n   * Called when the text column value is changed\r\n   */\n\n\n  AutoPopulateTextColumn.prototype.onBlur = function () {\n    this._value = this.inputElement.value;\n\n    this._notifyOutputChanged();\n  };\n  /**\r\n   * Called this function to auto populate the formatted test.\r\n   * @param newValue The new value of type Lookup.Regarding.\r\n   */\n\n\n  AutoPopulateTextColumn.prototype.autoPopulate = function (newValue) {\n    this._regardingValue = newValue;\n\n    if (newValue === null || newValue.length === 0) {\n      this.notify(\"\");\n    } else if (this.inputElement.value === \"\") {\n      this.getFormattedText(newValue[0].entityType, newValue[0].id);\n    }\n  };\n  /**\r\n   * Called this function to notify the framework when text value is changed.\r\n   * @param newText The new formmated text.\r\n   */\n\n\n  AutoPopulateTextColumn.prototype.notify = function (newText) {\n    this.inputElement.value = newText;\n    this._value = this.inputElement.value;\n\n    this._notifyOutputChanged();\n  };\n  /**\r\n   * Called this function to retrive the regarding record and format the output.\r\n   * @param tableType The table type of selected Lookup.Regarding.\r\n   * @param id The table id of selected Lookup.Regarding.\r\n   */\n\n\n  AutoPopulateTextColumn.prototype.getFormattedText = function (tableType, id) {\n    var _this = this;\n\n    var output = \"\";\n    var selectedTypeConfig = [];\n\n    var multiTypeConfig = this._configValue.split(\"^\");\n\n    if (multiTypeConfig.length === 0 || multiTypeConfig === null) {\n      this.notify(output);\n      return;\n    }\n\n    for (var _i = 0, multiTypeConfig_1 = multiTypeConfig; _i < multiTypeConfig_1.length; _i++) {\n      var typeConfig = multiTypeConfig_1[_i];\n      var config = typeConfig.split(\";\");\n\n      if (config[0] === tableType) {\n        selectedTypeConfig = config;\n        break;\n      }\n    }\n\n    if (selectedTypeConfig.length === 0 || selectedTypeConfig.length === null) {\n      this.notify(output);\n      return;\n    }\n\n    var selectCols = selectedTypeConfig[1].split(\",\");\n\n    this._context.webAPI.retrieveRecord(tableType, id, \"?$select=\" + selectedTypeConfig[1]).then(function (result) {\n      output = selectedTypeConfig !== undefined ? selectedTypeConfig[2] : \"\";\n\n      if (output !== \"\") {\n        selectCols.forEach(function (c) {\n          output = output.replace(c, result[c]);\n        });\n\n        _this.notify(output);\n      }\n    });\n  };\n\n  return AutoPopulateTextColumn;\n}();\n\nexports.AutoPopulateTextColumn = AutoPopulateTextColumn;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./AutoPopulateTextColumn/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('SatKar.AutoPopulateTextColumn', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.AutoPopulateTextColumn);
} else {
	var SatKar = SatKar || {};
	SatKar.AutoPopulateTextColumn = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.AutoPopulateTextColumn;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}